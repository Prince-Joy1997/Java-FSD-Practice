package com.stackroute.ust.BookExercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookExerciseApplication {

	public static void main(String[] args) {

		SpringApplication.run(BookExerciseApplication.class, args);
	}

}
